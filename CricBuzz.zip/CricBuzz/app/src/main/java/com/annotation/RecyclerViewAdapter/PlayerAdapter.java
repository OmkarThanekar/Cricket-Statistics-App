package com.annotation.RecyclerViewAdapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.annotation.Pojo.PlayerPojo;
import com.annotation.cricbuzz.R;

import java.util.List;

public class PlayerAdapter extends RecyclerView.Adapter<PlayerAdapter.ViewHolder> {

    private List<PlayerPojo> playerList;
    private OnItemClickListener mListner;

    public interface OnItemClickListener{
        void onItemClick(int position,int id);
        void onDeleteClick(int position,int id);
        void onEditClick(int position,int id);
    }

    public void setOnClickListener(OnItemClickListener listener){
        mListner = listener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_name,tv_role,tv_country,tv_dod;
        ImageButton btn_edit,btn_delete;
        ImageView iv_player;
        ConstraintLayout parentLayout;
        public ViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            tv_name=itemView.findViewById(R.id.player_list_item_tv_name);
            tv_role=itemView.findViewById(R.id.player_list_item_tv_role);
            tv_country=itemView.findViewById(R.id.player_list_item_tv_country);
            tv_dod=itemView.findViewById(R.id.player_list_item_tv_dod);

            btn_delete=itemView.findViewById(R.id.player_list_item_btn_delete);
            btn_edit=itemView.findViewById(R.id.player_list_item_btn_edit);

            iv_player=itemView.findViewById(R.id.player_list_item_iv);

            parentLayout=itemView.findViewById(R.id.player_list_item_cl);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null){
                        int position=getAdapterPosition();
                        if (position!=RecyclerView.NO_POSITION)
                        {
                            listener.onItemClick(position,Integer.parseInt(parentLayout.getTag().toString()));
                        }
                    }
                }
            });

            btn_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null){
                        int position=getAdapterPosition();
                        if (position!=RecyclerView.NO_POSITION)
                        {
                            listener.onDeleteClick(position,Integer.parseInt(parentLayout.getTag().toString()));
                        }
                    }
                }
            });

            btn_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null){
                        int position=getAdapterPosition();
                        if (position!=RecyclerView.NO_POSITION)
                        {
                            listener.onEditClick(position,Integer.parseInt(parentLayout.getTag().toString()));
                        }
                    }
                }
            });

        }
    }

    public PlayerAdapter(List<PlayerPojo> playerList) {
        this.playerList=playerList;
    }

    @NonNull
    @Override
    public PlayerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View listitem = LayoutInflater.from(parent.getContext()).inflate(R.layout.player_list_item, parent, false);

        return new ViewHolder(listitem,mListner);
    }

    @Override
    public void onBindViewHolder(@NonNull PlayerAdapter.ViewHolder holder, int position) {
        if (position%2==0)
            holder.parentLayout.setBackgroundColor(Color.parseColor("#9BD0DD"));
        else
            holder.parentLayout.setBackgroundColor(Color.parseColor("#62B6CB"));

        PlayerPojo playerPojo = playerList.get(position);
        holder.parentLayout.setTag(playerPojo.getP_id());
        holder.tv_name.setText("Name : "+playerPojo.getP_fname()+" "+playerPojo.getP_lname());
        holder.tv_role.setText("Role : "+playerPojo.getP_role());
        holder.tv_country.setText("Country : "+playerPojo.getP_country());
        holder.tv_dod.setText("Date Of Debut : "+playerPojo.getP_dod());

    }

    @Override
    public int getItemCount() {
        return playerList.size();
    }
}
