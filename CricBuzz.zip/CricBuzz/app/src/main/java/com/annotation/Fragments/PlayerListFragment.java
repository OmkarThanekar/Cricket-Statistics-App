package com.annotation.Fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.annotation.Constants.Utility;
import com.annotation.Database.DatabaseHelper;
import com.annotation.Pojo.PlayerPojo;
import com.annotation.RecyclerViewAdapter.PlayerAdapter;
import com.annotation.cricbuzz.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class PlayerListFragment extends Fragment implements View.OnClickListener {

    private FloatingActionButton floatingActionButton;
    private TextView tv_disclaimer;
    private RecyclerView recyclerView;
    private PlayerAdapter playerAdapter;
    private List<PlayerPojo> playerList;
    private DatabaseHelper databaseHelper;




    public PlayerListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_player_list, container, false);

        initView(view);
        initDatabase();
        initListeners();
        populateData();

        return view;
    }

    private void initDatabase() {
        databaseHelper=new DatabaseHelper(getActivity());
    }

    private void populateData() {
        playerList=databaseHelper.getAllPlayers();
        if (playerList.isEmpty()){ tv_disclaimer.setVisibility(View.VISIBLE);}
            else{tv_disclaimer.setVisibility(View.GONE);}
            playerAdapter = new PlayerAdapter(playerList);
            playerAdapter.notifyDataSetChanged();
            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
            recyclerView.setAdapter(playerAdapter);
            playerAdapter.setOnClickListener(new PlayerAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(int position, int id) {
                    loadViewPlayerInfoFragment(id);
                }

                @Override
                public void onDeleteClick(int position, int id) {
                    deletePlayer(position, id);
                }

                @Override
                public void onEditClick(int position, int id) {
                    loadPlayerAddFragment(Utility.MODEEDIT, id);

                }
            });

    }

    private void deletePlayer(final int position,final int id) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Confirm Delete Palyer?");
        builder.setMessage("Player having id " + id + " to be deleted.");
        builder.setPositiveButton("Yes", new DialogInterface
                .OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog,
                                int which) {
                int numOfRows=databaseHelper.deletePlayer(id);
                if (numOfRows>0)
                {
                    populateData();
                }
            }
        });
        builder.setNegativeButton("No",null);
        builder.setCancelable(false);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void initListeners() {
        floatingActionButton.setOnClickListener(this);
    }

    private void initView(View view) {
        floatingActionButton=view.findViewById(R.id.player_list_fab_add);
        recyclerView=view.findViewById(R.id.player_list_rv_players);
        tv_disclaimer=view.findViewById(R.id.player_list_tv_no_entry);
        getActivity().setTitle(R.string.home);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.player_list_fab_add:
//                Toast.makeText(getActivity(), "Hi I am Floating Action Button", Toast.LENGTH_SHORT).show();
                loadPlayerAddFragment(Utility.MODEADD);
                break;
        }
    }

    private void loadPlayerAddFragment(String mode)
    {
        FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        PlayerAdd playerAdd=new PlayerAdd(mode);
        fragmentTransaction.replace(R.id.main_fl_container,playerAdd,playerAdd.getTag());
        fragmentTransaction.addToBackStack(playerAdd.getTag());
        fragmentTransaction.commit();
    }
    private void loadPlayerAddFragment(String mode,int id)
    {
        FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        PlayerAdd playerAdd=new PlayerAdd(mode,id);
        fragmentTransaction.replace(R.id.main_fl_container,playerAdd,playerAdd.getTag());
        fragmentTransaction.addToBackStack(playerAdd.getTag());
        fragmentTransaction.commit();
    }

    private void loadViewPlayerInfoFragment(int id)
    {
        FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        ViewPlayerInfo viewPlayerInfo=new ViewPlayerInfo(id);
        fragmentTransaction.replace(R.id.main_fl_container,viewPlayerInfo,viewPlayerInfo.getTag());
        fragmentTransaction.addToBackStack(viewPlayerInfo.getTag());
        fragmentTransaction.commit();
    }
}
