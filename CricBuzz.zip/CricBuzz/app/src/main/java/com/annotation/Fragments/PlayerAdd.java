package com.annotation.Fragments;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.annotation.Constants.Utility;
import com.annotation.Database.DatabaseHelper;
import com.annotation.Pojo.PlayerPojo;
import com.annotation.cricbuzz.R;

import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 */
public class PlayerAdd extends Fragment implements View.OnClickListener, DatePickerDialog.OnDateSetListener {
    private EditText et_fname;
    private EditText et_lname;
    private EditText et_age;
    private EditText et_total_run;
    private EditText et_half_century;
    private EditText et_century;
    private EditText et_nickname;

    private RadioGroup rb_gender;
    private RadioButton rb_male;
    private RadioButton rb_female;

    private TextView tv_dod;

    private Spinner sp_country;
    private Spinner sp_role;
    private Spinner sp_bat_style;
    private Spinner sp_bowl_style;

    private Button btn_add_player;

    private DatabaseHelper databaseHelper;
    private PlayerPojo playerPojo;

    private Calendar calendar;

    private String mode;
    private int id;


    public PlayerAdd(String mode) {
        this.mode=mode;
    }
    public PlayerAdd(String mode,int id) {
        this.mode=mode;
        this.id=id;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_player_add,container,false);
        initViews(view);
        initDatabase();
        initData();
        if (Utility.MODEEDIT.equals(mode))
            populateData();
        initListners();

        return view;
    }

    private void populateData() {
        playerPojo=databaseHelper.getPlayer(id);
        et_fname.setText(playerPojo.getP_fname());
        et_lname.setText(playerPojo.getP_lname());
        tv_dod.setText(playerPojo.getP_dod());
        et_age.setText(Integer.toString(playerPojo.getP_age()));
        sp_country.setSelection(selectValue(sp_country,playerPojo.getP_country()));
        if (playerPojo.getP_gender().equals(rb_male.getText().toString()))
            rb_male.setChecked(true);
        else if (playerPojo.getP_gender().equals(rb_female.getText().toString()))
            rb_female.setChecked(true);
        sp_role.setSelection(selectValue(sp_role,playerPojo.getP_role()));
        sp_bat_style.setSelection(selectValue(sp_bat_style,playerPojo.getP_bat_style()));
        sp_bowl_style.setSelection(selectValue(sp_bowl_style,playerPojo.getP_bowl_style()));
        et_total_run.setText(playerPojo.getP_total_run());
        et_half_century.setText(playerPojo.getP_half_century());
        et_century.setText(playerPojo.getP_century());
        et_nickname.setText(playerPojo.getP_nickname());
    }

    private int selectValue(Spinner sp, String val) {
        for (int i=0;i<sp.getCount();i++){
            if (sp.getItemAtPosition(i).equals(val)){
                return i;
            }
        }
        return 0;
    }

    private void initData() {
        calendar=Calendar.getInstance();

        ArrayAdapter<String> countrySpinnerAdapter =new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,Utility.listCountry);
        countrySpinnerAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        sp_country.setAdapter(countrySpinnerAdapter);

        ArrayAdapter<String> roleSpinnerAdapter =new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,Utility.listRole);
        roleSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        sp_role.setAdapter(roleSpinnerAdapter);

        ArrayAdapter<String> batSpinnerAdapter =new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,Utility.listBattingStyle);
        batSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        sp_bat_style.setAdapter(batSpinnerAdapter);

        ArrayAdapter<String> bowlSpinnerAdapter =new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,Utility.listBowlingStyle);
        bowlSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        sp_bowl_style.setAdapter(bowlSpinnerAdapter);


    }

    private void initDatabase() {
        databaseHelper=new DatabaseHelper(getActivity());
    }

    private void initListners() {
        btn_add_player.setOnClickListener(this);
        tv_dod.setOnClickListener(this);
    }

    private void initViews(View view) {
        et_fname=view.findViewById(R.id.fragment_add_player_et_fname);
        et_lname=view.findViewById(R.id.fragment_add_player_et_lname);
        et_age=view.findViewById(R.id.fragment_add_player_et_age);
        et_total_run=view.findViewById(R.id.fragment_add_player_et_total_runs);
        et_half_century=view.findViewById(R.id.fragment_add_player_et_half_century);
        et_century=view.findViewById(R.id.fragment_add_player_et_century);
        et_nickname=view.findViewById(R.id.fragment_add_player_et_nickname);

        tv_dod=view.findViewById(R.id.fragment_add_player_tv_dod_picker);

        rb_gender=view.findViewById(R.id.fragment_add_player_rg_gender);
        rb_male=view.findViewById(R.id.fragment_add_player_rb_male);
        rb_female=view.findViewById(R.id.fragment_add_player_rb_female);

        sp_country=view.findViewById(R.id.fragment_add_player_sp_country);
        sp_role=view.findViewById(R.id.fragment_add_player_sp_role);
        sp_bat_style=view.findViewById(R.id.fragment_add_player_sp_bat_style);
        sp_bowl_style=view.findViewById(R.id.fragment_add_player_sp_bowl_style);

        btn_add_player=view.findViewById(R.id.fragment_add_player_btn_add);

        if (Utility.MODEEDIT.equals(mode)){
            btn_add_player.setText(R.string.edit_player);
            getActivity().setTitle(R.string.edit_player);
        }
        else if (Utility.MODEADD.equals(mode))
        {
            getActivity().setTitle(R.string.add_player);
        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.fragment_add_player_btn_add:
                if(validateFname()&validateDod()&validateLname()&validateAge()&validateTotalRuns()&validateHalfCen()&validateCen()&validateNickName()) {
                    if (validateRuns()) {
                        if (Utility.MODEADD.equals(mode)) {
                            long result = databaseHelper.addPlayer(setValues());
                            if (result != 0L) {
//                        Toast.makeText(getActivity(), "Player created with id: " + result, Toast.LENGTH_LONG).show();
                                this.id = (int) result;
                                createAlert();
                            }
                        } else if (Utility.MODEEDIT.equals(mode)) {
                            int res = databaseHelper.editPlayer(setValues());
                            if (res > 0) {
                                createAlert();
                            }
                        }
                    }
                }
                break;
            case R.id.fragment_add_player_tv_dod_picker:
                showDatePickerDialog();
                break;
        }
    }

    private boolean validateRuns() {
        int halfcen=Integer.parseInt(et_half_century.getText().toString().trim());
        int cen=Integer.parseInt(et_century.getText().toString().trim());
        int totalrun=Integer.parseInt(et_total_run.getText().toString().trim());

        int total=(cen*100)+(halfcen*50);
        if (totalrun>=total)
        {
            return true;
        }
        else {
            et_total_run.setError("Total runs cannot be less than centuries and half centuries combined.");
            et_total_run.requestFocus();
            return false;
        }
    }

    private boolean validateFname() {
        if (et_fname.getText().toString().trim().isEmpty())
        {
            et_fname.setError("Field cannot be empty.");
            et_fname.requestFocus();
            return false;
        }
        else
        {
            et_fname.setError(null);
            return true;
        }
    }
    private boolean validateLname() {
        if (et_lname.getText().toString().trim().isEmpty())
        {
            et_lname.setError("Field cannot be empty.");
            et_lname.requestFocus();
            return false;
        }
        else
        {
            et_lname.setError(null);
            return true;
        }
    }
    private boolean validateDod() {
        if (tv_dod.getText().toString().trim().equals("DD-MM-YYYY"))
        {
            tv_dod.setError("Field cannot be empty.");
            tv_dod.requestFocus();
            return false;
        }
        else
        {
            tv_dod.setError(null);
            return true;
        }
    }
    private boolean validateAge() {
        if (et_age.getText().toString().trim().isEmpty())
        {
            et_age.setError("Field cannot be empty.");
            et_age.requestFocus();
            return false;
        }
        else if (!(13<=Integer.parseInt(et_age.getText().toString().trim()) & Integer.parseInt(et_age.getText().toString().trim())<=60))
        {
            et_age.setError("Age must be in range 13-60.");
            return false;
        }
        else
        {
            et_age.setError(null);
            return true;
        }
    }
    private boolean validateTotalRuns() {
        if (et_total_run.getText().toString().trim().isEmpty())
        {
            et_total_run.setError("Field cannot be empty.");
            et_total_run.requestFocus();
            return false;
        }
        else
        {
            et_total_run.setError(null);
            return true;
        }
    }

    private boolean validateHalfCen() {
        if (et_half_century.getText().toString().trim().isEmpty())
        {
            et_half_century.setError("Field cannot be empty.");
            et_half_century.requestFocus();
            return false;
        }
        else
        {
            et_half_century.setError(null);
            return true;
        }
    }
    private boolean validateCen() {
        if (et_century.getText().toString().trim().isEmpty())
        {
            et_century.setError("Field cannot be empty.");
            et_century.requestFocus();
            return false;
        }
        else
        {
            et_century.setError(null);
            return true;
        }
    }
    private boolean validateNickName() {
        if (et_nickname.getText().toString().trim().isEmpty())
        {
            et_nickname.setError("Field cannot be empty.");
            et_nickname.requestFocus();
            return false;
        }
        else
        {
            et_nickname.setError(null);
            return true;
        }
    }

    public void createAlert(){
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        if (Utility.MODEEDIT.equals(mode)) {
            builder.setTitle("Player Edited Successfully.");
            builder.setMessage("Player having id " + id + " updated.");
            builder.setPositiveButton("Ok", new DialogInterface
                    .OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog,
                                    int which) {
                    backToHome();
                }
            });
            builder.setCancelable(false);
        }
        else if (Utility.MODEADD.equals(mode)){
            builder.setTitle("Player Added Successfully.");
            builder.setMessage("Player with id " + id +  " added.");
            builder.setPositiveButton("Ok", new DialogInterface
                    .OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog,
                                    int which) {
                    backToHome();
                }
            });
            builder.setCancelable(false);
        }
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void backToHome()
    {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        PlayerListFragment playerListFragment = new PlayerListFragment();
        for (int i = 0; i < fragmentManager.getBackStackEntryCount(); ++i) {
            fragmentManager.popBackStack();
        }
        fragmentTransaction.replace(R.id.main_fl_container, playerListFragment, playerListFragment.getTag()).commit();

    }

    public PlayerPojo setValues()
    {
        PlayerPojo playerPojo = new PlayerPojo();
        if (Utility.MODEEDIT.equals(mode))
            playerPojo.setP_id(id);
        playerPojo.setP_fname(et_fname.getText().toString().trim());
        playerPojo.setP_lname(et_lname.getText().toString().trim());
        playerPojo.setP_dod(tv_dod.getText().toString().trim());
        playerPojo.setP_country(sp_country.getSelectedItem().toString());
        playerPojo.setP_age(Integer.parseInt(et_age.getText().toString().trim()));
        if(rb_gender.getCheckedRadioButtonId()==R.id.fragment_add_player_rb_male)
            playerPojo.setP_gender(rb_male.getText().toString());
        else if (rb_gender.getCheckedRadioButtonId()==R.id.fragment_add_player_rb_female)
            playerPojo.setP_gender(rb_female.getText().toString());
        playerPojo.setP_role(sp_role.getSelectedItem().toString());
        playerPojo.setP_bat_style(sp_bat_style.getSelectedItem().toString());
        playerPojo.setP_bowl_style(sp_bowl_style.getSelectedItem().toString());
        playerPojo.setP_total_run(et_total_run.getText().toString().trim());
        playerPojo.setP_half_century(et_half_century.getText().toString().trim());
        playerPojo.setP_century(et_century.getText().toString().trim());
        playerPojo.setP_nickname(et_nickname.getText().toString().trim());
        return playerPojo;
    }

    private void showDatePickerDialog(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), this, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.getDatePicker().setMaxDate(Calendar.getInstance().getTimeInMillis());
        datePickerDialog.show();
    }

    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        calendar.set(i, i1, i2);

        String date;
        String month;

        if(i2 < 10){
            date = "0" + i2;
        }
        else{
            date = String.valueOf(i2);
        }

        if(i1 < 9){
            month = "0" + (i1 + 1);
        }
        else{
            month = String.valueOf(i1 + 1);
        }

        tv_dod.setText(date + "-" + month + "-" + i);
    }
}
