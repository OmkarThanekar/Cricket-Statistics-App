package com.annotation.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.annotation.Constants.Utility;
import com.annotation.Pojo.PlayerPojo;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    public DatabaseHelper(@Nullable Context context) {
        super(context, Utility.DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_PLAYER = "CREATE TABLE "
                + Utility.TABLE_NAME + " ("
                + Utility.PLAYER_TABLE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Utility.PLAYER_TABLE_FNAME + " text, "
                + Utility.PLAYER_TABLE_LNAME + " text, "
                + Utility.PLAYER_TABLE_DOD + " text, "
                + Utility.PLAYER_TABLE_COUNTRY + " text, "
                + Utility.PLAYER_TABLE_AGE + " INTEGER, "
                + Utility.PLAYER_TABLE_GENDER + " text, "
                + Utility.PLAYER_TABLE_ROLE + " text, "
                + Utility.PLAYER_TABLE_BAT_STYLE + " text, "
                + Utility.PLAYER_TABLE_BOWL_STYLE + " text, "
                + Utility.PLAYER_TABLE_TOTAL_RUN + " text, "
                + Utility.PLAYER_TABLE_HALF_CENTURY + " text, "
                + Utility.PLAYER_TABLE_CENTURY + " text, "
                + Utility.PLAYER_TABLE_NICKNAME + " text) ";
        db.execSQL(CREATE_TABLE_PLAYER);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

//    Add player method

    public long addPlayer(PlayerPojo playerPojo){
        long playerId;
        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(Utility.PLAYER_TABLE_FNAME, playerPojo.getP_fname());
        contentValues.put(Utility.PLAYER_TABLE_LNAME, playerPojo.getP_lname());
        contentValues.put(Utility.PLAYER_TABLE_DOD, playerPojo.getP_dod());
        contentValues.put(Utility.PLAYER_TABLE_COUNTRY, playerPojo.getP_country());
        contentValues.put(Utility.PLAYER_TABLE_AGE, playerPojo.getP_age());
        contentValues.put(Utility.PLAYER_TABLE_GENDER, playerPojo.getP_gender());
        contentValues.put(Utility.PLAYER_TABLE_ROLE, playerPojo.getP_role());
        contentValues.put(Utility.PLAYER_TABLE_BAT_STYLE, playerPojo.getP_bat_style());
        contentValues.put(Utility.PLAYER_TABLE_BOWL_STYLE, playerPojo.getP_bowl_style());
        contentValues.put(Utility.PLAYER_TABLE_TOTAL_RUN, playerPojo.getP_total_run());
        contentValues.put(Utility.PLAYER_TABLE_HALF_CENTURY, playerPojo.getP_half_century());
        contentValues.put(Utility.PLAYER_TABLE_CENTURY, playerPojo.getP_century());
        contentValues.put(Utility.PLAYER_TABLE_NICKNAME, playerPojo.getP_nickname());

        playerId = db.insert(Utility.TABLE_NAME, null, contentValues);
        db.close();

        return playerId;
    }

//    Provides list for recycler view

    public List<PlayerPojo> getAllPlayers() {
        List<PlayerPojo> playerlist = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(Utility.TABLE_NAME,null,null,null,null,null,null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                PlayerPojo playerPojo = new PlayerPojo();

                playerPojo.setP_id(cursor.getInt(cursor.getColumnIndex(Utility.PLAYER_TABLE_ID)));
                playerPojo.setP_fname(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_FNAME)));
                playerPojo.setP_lname(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_LNAME)));
                playerPojo.setP_role(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_ROLE)));
                playerPojo.setP_country(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_COUNTRY)));
                playerPojo.setP_dod(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_DOD)));
                playerlist.add(playerPojo);
            } while (cursor.moveToNext());
        }
        return playerlist;
    }

//  Delete player corresponding to id
    public int deletePlayer(int id){
        String key=Integer.toString(id);
        SQLiteDatabase db = getWritableDatabase();
        int res=db.delete(Utility.TABLE_NAME, Utility.PLAYER_TABLE_ID + " = ?", new String[]{key});
        db.close();
        return res;
    }

//    get all data corresponding to id
public PlayerPojo getPlayer(int id) {
    PlayerPojo playerPojo = new PlayerPojo();
    SQLiteDatabase db = getReadableDatabase();
    Cursor cursor=db.rawQuery("select * from "+ Utility.TABLE_NAME+ " where "+Utility.PLAYER_TABLE_ID+"='"+id+"'",null);
    if (cursor != null && cursor.moveToFirst()) {
        do {
            playerPojo.setP_id(cursor.getInt(cursor.getColumnIndex(Utility.PLAYER_TABLE_ID)));
            playerPojo.setP_fname(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_FNAME)));
            playerPojo.setP_lname(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_LNAME)));
            playerPojo.setP_dod(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_DOD)));
            playerPojo.setP_age(cursor.getInt(cursor.getColumnIndex(Utility.PLAYER_TABLE_AGE)));
            playerPojo.setP_country(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_COUNTRY)));
            playerPojo.setP_gender(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_GENDER)));
            playerPojo.setP_role(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_ROLE)));
            playerPojo.setP_bat_style(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_BAT_STYLE)));
            playerPojo.setP_bowl_style(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_BOWL_STYLE)));
            playerPojo.setP_total_run(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_TOTAL_RUN)));
            playerPojo.setP_half_century(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_HALF_CENTURY)));
            playerPojo.setP_century(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_CENTURY)));
            playerPojo.setP_nickname(cursor.getString(cursor.getColumnIndex(Utility.PLAYER_TABLE_NICKNAME)));
        } while (cursor.moveToNext());
    }
    return playerPojo;
}

// update player method
public int editPlayer(PlayerPojo playerPojo){
    int numOfRows;
    SQLiteDatabase db = getWritableDatabase();

   String id=Integer.toString(playerPojo.getP_id());

    ContentValues contentValues = new ContentValues();
    contentValues.put(Utility.PLAYER_TABLE_FNAME, playerPojo.getP_fname());
    contentValues.put(Utility.PLAYER_TABLE_LNAME, playerPojo.getP_lname());
    contentValues.put(Utility.PLAYER_TABLE_DOD, playerPojo.getP_dod());
    contentValues.put(Utility.PLAYER_TABLE_COUNTRY, playerPojo.getP_country());
    contentValues.put(Utility.PLAYER_TABLE_AGE, playerPojo.getP_age());
    contentValues.put(Utility.PLAYER_TABLE_GENDER, playerPojo.getP_gender());
    contentValues.put(Utility.PLAYER_TABLE_ROLE, playerPojo.getP_role());
    contentValues.put(Utility.PLAYER_TABLE_BAT_STYLE, playerPojo.getP_bat_style());
    contentValues.put(Utility.PLAYER_TABLE_BOWL_STYLE, playerPojo.getP_bowl_style());
    contentValues.put(Utility.PLAYER_TABLE_TOTAL_RUN, playerPojo.getP_total_run());
    contentValues.put(Utility.PLAYER_TABLE_HALF_CENTURY, playerPojo.getP_half_century());
    contentValues.put(Utility.PLAYER_TABLE_CENTURY, playerPojo.getP_century());
    contentValues.put(Utility.PLAYER_TABLE_NICKNAME, playerPojo.getP_nickname());

    numOfRows = db.update(Utility.TABLE_NAME, contentValues, Utility.PLAYER_TABLE_ID + " = ?", new String[]{id});
    db.close();

    return numOfRows;
}


}
