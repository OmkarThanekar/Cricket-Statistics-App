package com.annotation.cricbuzz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.annotation.Fragments.PlayerListFragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loadFragment();
    }

    private void loadFragment() {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        PlayerListFragment playerListFragment = new PlayerListFragment();
        fragmentTransaction.replace(R.id.main_fl_container,playerListFragment,playerListFragment.getTag());
        fragmentTransaction.commit();
    }
}
