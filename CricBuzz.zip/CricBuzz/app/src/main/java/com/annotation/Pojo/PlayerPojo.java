package com.annotation.Pojo;

public class PlayerPojo {
    private int p_id;
    private String p_fname;
    private String p_lname;
    private String  p_dod;
    private int p_age;
    private String  p_country;
    private String  p_gender;
    private String  p_role;
    private String  p_bat_style;
    private String p_bowl_style;
    private String  p_total_run;
    private String  p_half_century;
    private String  p_century;

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public String getP_fname() {
        return p_fname;
    }

    public void setP_fname(String p_fname) {
        this.p_fname = p_fname;
    }

    public String getP_lname() {
        return p_lname;
    }

    public void setP_lname(String p_lname) {
        this.p_lname = p_lname;
    }

    public String getP_dod() {
        return p_dod;
    }

    public void setP_dod(String p_dod) {
        this.p_dod = p_dod;
    }

    public int getP_age() {
        return p_age;
    }

    public void setP_age(int p_age) {
        this.p_age = p_age;
    }

    public String getP_country() {
        return p_country;
    }

    public void setP_country(String p_country) {
        this.p_country = p_country;
    }

    public String getP_gender() {
        return p_gender;
    }

    public void setP_gender(String p_gender) {
        this.p_gender = p_gender;
    }

    public String getP_role() {
        return p_role;
    }

    public void setP_role(String p_role) {
        this.p_role = p_role;
    }

    public String getP_bat_style() {
        return p_bat_style;
    }

    public void setP_bat_style(String p_bat_style) {
        this.p_bat_style = p_bat_style;
    }

    public String getP_bowl_style() {
        return p_bowl_style;
    }

    public void setP_bowl_style(String p_bowl_style) {
        this.p_bowl_style = p_bowl_style;
    }

    public String getP_total_run() {
        return p_total_run;
    }

    public void setP_total_run(String p_total_run) {
        this.p_total_run = p_total_run;
    }

    public String getP_half_century() {
        return p_half_century;
    }

    public void setP_half_century(String p_half_century) {
        this.p_half_century = p_half_century;
    }

    public String getP_century() {
        return p_century;
    }

    public void setP_century(String p_century) {
        this.p_century = p_century;
    }

    public String getP_nickname() {
        return p_nickname;
    }

    public void setP_nickname(String p_nickname) {
        this.p_nickname = p_nickname;
    }

    private String  p_nickname;
}
